package com.visuallevel.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Surface
import android.util.Size
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: LevelOverlay
    private lateinit var resultText: TextView
    private lateinit var capacityInput: EditText
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val latest = AtomicReference<Detection?>(null)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else resultText.text = "Permissão da câmera necessária."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val header = TextView(this).apply {
            text = "VISUAL LEVEL  •  GALAXY M35  •  0.2"
            setTextColor(Color.WHITE); textSize = 18f
            setPadding(18, 18, 18, 12)
        }
        root.addView(header)

        val cameraFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        overlay = LevelOverlay(this)
        cameraFrame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(cameraFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 16)
        }
        resultText = TextView(this).apply {
            text = "Aguardando imagem da câmera…"
            setTextColor(Color.WHITE); textSize = 17f
        }
        panel.addView(resultText)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        capacityInput = EditText(this).apply {
            hint = "Capacidade (L), opcional"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
        }
        row.addView(capacityInput, LinearLayout.LayoutParams(0, -2, 1f))
        val refresh = Button(this).apply {
            text = "Atualizar"
            setOnClickListener { updateResult(latest.get()) }
        }
        row.addView(refresh)
        panel.addView(row)

        val note = TextView(this).apply {
            text = "Enquadre o recipiente dentro das guias. Leitura experimental: bordas, reflexos e iluminação podem gerar falsos níveis."
            setTextColor(Color.LTGRAY); textSize = 12f
        }
        panel.addView(note)
        root.addView(panel)
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            // A tela do Galaxy M35 é usada em retrato. Definimos a rotação
            // nos dois casos de uso para manter os metadados alinhados à interface.
            val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 960),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()

            val preview = Preview.Builder()
                .setTargetRotation(rotation)
                .build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
            val analysis = ImageAnalysis.Builder()
                .setTargetRotation(rotation)
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { image ->
                val detection = LiquidBoundaryAnalyzer.detect(image)
                latest.set(detection)
                runOnUiThread {
                    overlay.levelFraction = detection?.fraction
                    overlay.invalidate()
                    updateResult(detection)
                }
                image.close()
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                resultText.text = "Não foi possível iniciar a câmera: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateResult(d: Detection?) {
        if (d == null) {
            resultText.text = "Não foi possível estimar uma linha horizontal."
            return
        }
        val percent = (d.fraction * 100).coerceIn(0.0, 100.0)
        val capacity = capacityInput.text.toString().replace(",", ".").toDoubleOrNull()
        val liters = capacity?.takeIf { it > 0 }?.let { it * percent / 100.0 }
        val volumeText = liters?.let { "\nVolume aproximado: %.1f L".format(it) } ?: ""
        resultText.text = "Preenchimento visual estimado: %.0f%%%s\nContraste da borda: %.1f".format(
            percent, volumeText, d.contrast
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}

data class Detection(val fraction: Double, val contrast: Double)

/**
 * Proof-of-concept detector:
 * averages luminance (Y) across a central horizontal band in upright
 * display coordinates and finds the strongest row-to-row transition.
 * This is NOT a validated liquid/meniscus classifier.
 */
object LiquidBoundaryAnalyzer {
    fun detect(image: androidx.camera.core.ImageProxy): Detection? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val rawWidth = image.width
        val rawHeight = image.height
        val rotation = image.imageInfo.rotationDegrees
        val rotated = rotation == 90 || rotation == 270
        val width = if (rotated) rawHeight else rawWidth
        val height = if (rotated) rawWidth else rawHeight
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val top = (height * 0.18).toInt()
        val bottom = (height * 0.88).toInt()
        val xStart = (width * 0.22).toInt()
        val xEnd = (width * 0.78).toInt()
        if (bottom - top < 20 || xEnd <= xStart) return null

        fun rowMean(y: Int): Double {
            var sum = 0L
            var count = 0
            val step = maxOf(1, (xEnd - xStart) / 160)
            var x = xStart
            while (x < xEnd) {
                // Converte coordenadas da imagem já rotacionada para o buffer Y original.
                val rawX: Int
                val rawY: Int
                when (rotation) {
                    90 -> { rawX = y; rawY = rawHeight - 1 - x }
                    180 -> { rawX = rawWidth - 1 - x; rawY = rawHeight - 1 - y }
                    270 -> { rawX = rawWidth - 1 - y; rawY = x }
                    else -> { rawX = x; rawY = y }
                }
                val index = rawY * rowStride + rawX * pixelStride
                if (rawX in 0 until rawWidth && rawY in 0 until rawHeight &&
                    index >= 0 && index < buffer.limit()) {
                    sum += (buffer.get(index).toInt() and 0xFF)
                    count++
                }
                x += step
            }
            return if (count == 0) 0.0 else sum.toDouble() / count
        }

        var bestY = -1
        var bestDiff = 0.0
        for (y in top + 2 until bottom - 2) {
            val diff = abs(rowMean(y + 2) - rowMean(y - 2))
            if (diff > bestDiff) {
                bestDiff = diff
                bestY = y
            }
        }
        if (bestY < 0 || bestDiff < 3.0) return null

        // Fraction is relative to the fixed guide area, not a physical tank boundary.
        val fraction = ((bottom - bestY).toDouble() / (bottom - top)).coerceIn(0.0, 1.0)
        return Detection(fraction, bestDiff)
    }
}

class LevelOverlay(context: android.content.Context) : View(context) {
    var levelFraction: Double? = null
    private val guidePaint = android.graphics.Paint().apply {
        color = Color.WHITE; alpha = 190; strokeWidth = 3f
        style = android.graphics.Paint.Style.STROKE
    }
    private val levelPaint = android.graphics.Paint().apply {
        color = Color.rgb(0, 230, 160); strokeWidth = 5f
    }
    private val textPaint = android.graphics.Paint().apply {
        color = Color.WHITE; textSize = 32f; isFakeBoldText = true
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val left = width * 0.16f
        val right = width * 0.84f
        val top = height * 0.18f
        val bottom = height * 0.88f
        canvas.drawRect(left, top, right, bottom, guidePaint)
        canvas.drawText("Mantenha o recipiente nas guias", left, top - 18f, textPaint)
        levelFraction?.let {
            val y = bottom - (bottom - top) * it.toFloat()
            canvas.drawLine(left, y, right, y, levelPaint)
            canvas.drawText("Nível detectado", left, y - 12f, textPaint)
        }
    }
}
