# Visual Level — protótipo Android 0.2 (perfil de teste Galaxy M35)

Aplicativo experimental em Kotlin com CameraX, preparado para testes em Samsung Galaxy M35. Usa a câmera traseira, solicita análise 4:3 próxima de 1280×960 quando suportada pelo dispositivo, mantém apenas o quadro mais recente e considera a rotação informada pela câmera ao analisar a imagem.

## Abrir e executar
1. Instale o Android Studio (versão compatível com Android Gradle Plugin 8.7.3).
2. Abra a pasta `VisualLevel_Android_Prototype`.
3. Aguarde a sincronização do Gradle.
4. Conecte um celular Android (API 26 ou superior), habilite depuração USB e execute.
5. Autorize o acesso à câmera.

## Ajustes para Samsung Galaxy M35
- Usa CameraX com seleção de resolução 4:3 e alvo de análise de 1280×960; o CameraX pode negociar outra resolução conforme a câmera e o aparelho.
- Define a rotação dos casos de uso e converte as coordenadas do buffer Y para orientação de tela antes de procurar a transição.
- Mantém `STRATEGY_KEEP_ONLY_LATEST` para evitar fila de quadros e reduzir latência/carga.
- Usa a câmera traseira principal por meio de `CameraSelector.DEFAULT_BACK_CAMERA`; a seleção física de lente não é garantida pela API genérica.

## Como testar
- Posicione um recipiente transparente e vertical dentro das guias.
- Use um líquido com contraste visual em relação ao fundo.
- Evite reflexos, contraluz, movimento e superfícies curvas.
- Opcionalmente, informe a capacidade total em litros. O volume exibido é capacidade × percentual visual.

## Limitações conhecidas
- Esta versão é uma prova de conceito, não um instrumento de medição validado.
- O algoritmo detecta a maior transição horizontal de brilho; pode confundir bordas, rótulos, sombras e reflexos com a superfície do líquido.
- As guias são uma região de análise da imagem, não os limites físicos detectados do recipiente. Portanto, o percentual atual é apenas uma estimativa visual e não deve ser usado como leitura confiável de nível.
- O volume calculado assume implicitamente relação linear entre altura e volume. Isso só é aproximadamente válido para recipientes verticais de seção transversal constante.
- Não há calibração métrica automática nesta primeira versão. Para converter pixels em centímetros ou litros com confiabilidade, será necessário reconhecer os limites reais do recipiente e obter uma escala por dimensão conhecida, marcador ou cadastro/calibração.
- Menisco, líquidos incolores, recipientes curvos, tanques horizontais e superfícies agitadas exigem algoritmos específicos.

## Próximas etapas recomendadas
1. Detecção real do contorno do recipiente e da linha do líquido.
2. Segmentação treinada para menisco/superfície em imagens laboratoriais e industriais.
3. Calibração por referência conhecida ou cadastro de dimensões.
4. Modelos de volume: prismático, cilindro vertical, cilindro horizontal e geometrias personalizadas.
5. Testes contra régua/volume de referência para medir erro e estabelecer limites de uso.

## Estrutura
- `MainActivity.kt`: interface, ciclo da câmera e apresentação.
- `LiquidBoundaryAnalyzer`: algoritmo inicial de detecção de transição horizontal.
- `LevelOverlay`: guias e linha sobre a prévia da câmera.
